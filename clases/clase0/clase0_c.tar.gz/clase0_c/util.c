
#include <stdio.h>

extern int m;


void mostrar_hola_mundo(int c, char b) {

	printf("Hola mundo. La var c vale %i \n", c);
	printf("La letra b = %c \n", b);

	char d = 'z';

	int i;

	if (d == 40)  
		printf ("d es igual a 40! \n");
	else if (d == 'z') 
		printf ("d es z! \n");

	for (i=0;  i<10; i++) {
		printf("i= %i \n", i);

	}


	while (i>0) {
		printf("i= %i \n", i);
		i--;
	}

	if (i == 0) {
		printf("ES CERO OBVIO\n");
	} else {
		printf("NO ES CERO OBVIO\n");
	}
}
