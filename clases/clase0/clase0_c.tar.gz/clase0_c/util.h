
void mostrar_hola_mundo(int c, char b);
