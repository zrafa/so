#include "util.h"

int m = 40;


int main () {

	mostrar_hola_mundo(3, 'z');

}
