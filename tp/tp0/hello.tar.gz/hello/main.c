
#include <stdio.h>
#include "foo.h"

int main(void)
{
	int i;
	int n, j;

	printf("Hola Mundo! \n");

	i = 2;
	j = i + 3;
	printf("j is %d\n", j);

	n = foo(i);
	printf("n como letra %c \n", n);

	return 0;
}


