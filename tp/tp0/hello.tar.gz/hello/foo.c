
#include <stdio.h>

char foo(int x)
{
	printf("I am foo! %i\n", x);
	return x + 'a';
}

