
#ifndef FOO_H
#define FOO_H

char foo(int x);

#endif	/* de FOO_H */
