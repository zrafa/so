#include <xinu.h>
#include "oso.h"

int32 rojo = 0x00ff0000;
int x = 0;
int y = 0;

void mostrar_imagen()
{
	for (int y=0;y<128; y++) {
	for (int x=0;x<128; x++) {
		/*   pintar un pixel en la coordenada x,y :
		 *   pixel(x, y, color);
		 */
		pixel (x, y, oso[y*128+x] );
	}
	}
}

process imagen()
{
	mostrar_imagen();
}
