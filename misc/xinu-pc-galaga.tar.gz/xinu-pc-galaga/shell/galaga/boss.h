#ifndef BOSS_BITMAP_H
#define BOSS_BITMAP_H
extern const unsigned short boss[225];
#define BOSS_WIDTH 15
#define BOSS_HEIGHT 15
#endif