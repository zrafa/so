
#ifndef EXTRAS_H
#define EXTRAS_H

void paint_screen();
void print_text_on_vga(unsigned int x, unsigned int y, char *text);

#endif
