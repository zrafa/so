#include <stdio.h>

char abc[26] = {
    'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j',
    'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't',
    'u', 'v', 'w', 'x', 'y', 'z'
};

int codifica = 0; /* variable para conocer si codificar o decodificar */

void main(int argc, char *argv[])
{
    if (argc != 2) {
        printf("Uso: %s [c | d]\n", argv[0]); return;
    }

    if (*argv[1] == 'c') {
        codifica = 1;
        printf("codificar\n");
    } else { 
	codifica = 0;
        printf("decodificar\n");
    }


    printf("letra del indice 4 del arreglo abc[] : %c \n", abc[4]);


    return;
}
